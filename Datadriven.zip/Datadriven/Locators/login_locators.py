# all locators in one file

class zenLocators:
    username = "//input[@name='username']"
    password = "//input[@name='password']"
    submit_button = "//button[@type='submit']"
    url = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login"
    dashboard_url = "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index"
    excel_file = "E:\\Priyanka\\workspace\\Datadriven\\Data\\test_data.xlsx"
    sheet_number = "Sheet1"
    pass_data = "TEST PASS"
    fail_data = "TEST FAILED"
    image_tag = "//div//ul//li//span//img"
    log_out = "//div//ul//li//ul//li//a[text()='Logout']"
    drop_down = "//i[@class ='oxd-icon bi-caret-down-fill oxd-userdropdown-icon']"
